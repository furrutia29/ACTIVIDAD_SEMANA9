package dao;

import conexion.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class ReporteDAO {
    public List<Object[]> masPrestados() throws SQLException {
        String sql="SELECT l.titulo, l.autor, COUNT(p.id) cantidad FROM libros l LEFT JOIN prestamos p ON l.id=p.id_libro GROUP BY l.id,l.titulo,l.autor ORDER BY cantidad DESC,l.titulo";
        return consultar(sql,0);
    }
    public List<Object[]> activos() throws SQLException {
        String sql="SELECT p.id,e.nombre,l.titulo,p.fecha_prestamo,p.fecha_devolucion,CASE WHEN p.fecha_devolucion<CURDATE() THEN 'ATRASADO' ELSE 'VIGENTE' END FROM prestamos p JOIN estudiantes e ON p.id_estudiante=e.id JOIN libros l ON p.id_libro=l.id WHERE p.devuelto=FALSE ORDER BY p.fecha_devolucion";
        return consultar(sql,0);
    }
    public List<Object[]> historial(int estudiante) throws SQLException {
        String sql="SELECT p.id,l.titulo,p.fecha_prestamo,p.fecha_devolucion,CASE WHEN p.devuelto THEN 'DEVUELTO' WHEN p.fecha_devolucion<CURDATE() THEN 'ATRASADO' ELSE 'VIGENTE' END FROM prestamos p JOIN libros l ON p.id_libro=l.id WHERE p.id_estudiante=? ORDER BY p.id DESC";
        return consultar(sql,estudiante);
    }
    public List<Object[]> devoluciones() throws SQLException {
        String sql="SELECT d.id_prestamo,e.nombre,l.titulo,d.fecha_real,d.dias_atraso FROM registro_devoluciones d JOIN prestamos p ON d.id_prestamo=p.id JOIN estudiantes e ON p.id_estudiante=e.id JOIN libros l ON p.id_libro=l.id ORDER BY d.fecha_real DESC,d.id DESC";
        return consultar(sql,0);
    }
    private List<Object[]> consultar(String sql,int idEstudiante) throws SQLException {
        List<Object[]> datos=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();PreparedStatement p=c.prepareStatement(sql)) {
            if(idEstudiante>0) p.setInt(1,idEstudiante);
            try(ResultSet r=p.executeQuery()) {
                int cols=r.getMetaData().getColumnCount();
                while(r.next()) {
                    Object[] fila=new Object[cols];
                    for(int i=0;i<cols;i++) fila[i]=r.getObject(i+1);
                    datos.add(fila);
                }
            }
        }
        return datos;
    }
}
