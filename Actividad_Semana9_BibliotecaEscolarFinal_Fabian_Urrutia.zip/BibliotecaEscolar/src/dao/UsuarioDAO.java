package dao;

import conexion.DatabaseConnection;
import modelo.Usuario;
import java.sql.*;
import java.util.*;

public class UsuarioDAO {
    private Usuario convertir(ResultSet r) throws SQLException {
        return new Usuario(r.getInt("id"),r.getString("nombre"),r.getString("rut"),r.getString("correo"),
                r.getString("contraseña"),r.getString("rol"));
    }
    public Usuario autenticar(String correo,String clave) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM usuarios WHERE LOWER(correo)=LOWER(?) AND `contraseña`=?")) {
            p.setString(1,correo.trim());p.setString(2,clave);
            try(ResultSet r=p.executeQuery()) {return r.next()?convertir(r):null;}
        }
    }
    public List<Usuario> listar() throws SQLException {
        List<Usuario> datos=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM usuarios ORDER BY nombre");ResultSet r=p.executeQuery()) {
            while(r.next()) datos.add(convertir(r));
        }
        return datos;
    }
    public Usuario buscarPorId(int id) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM usuarios WHERE id=?")) {
            p.setInt(1,id);try(ResultSet r=p.executeQuery()) {return r.next()?convertir(r):null;}
        }
    }
    public boolean insertar(Usuario x) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("INSERT INTO usuarios(nombre,rut,correo,`contraseña`,rol) VALUES(?,?,?,?,?)")) {
            parametros(p,x);return p.executeUpdate()>0;
        }
    }
    public boolean actualizar(Usuario x) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("UPDATE usuarios SET nombre=?,rut=?,correo=?,`contraseña`=?,rol=? WHERE id=?")) {
            parametros(p,x);p.setInt(6,x.getId());return p.executeUpdate()>0;
        }
    }
    private void parametros(PreparedStatement p,Usuario x) throws SQLException {
        p.setString(1,x.getNombre());p.setString(2,x.getRut());p.setString(3,x.getCorreo());
        p.setString(4,x.getContrasena());p.setString(5,x.getRol());
    }
    public boolean eliminar(int id) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("DELETE FROM usuarios WHERE id=?")) {
            p.setInt(1,id);return p.executeUpdate()>0;
        }
    }
}
