package dao;

import conexion.DatabaseConnection;
import modelo.Estudiante;
import java.sql.*;
import java.util.*;

public class EstudianteDAO {
    private Estudiante convertir(ResultSet r) throws SQLException {
        return new Estudiante(r.getInt("id"),r.getString("nombre"),r.getString("rut"),r.getString("correo"),r.getString("curso"));
    }
    public List<Estudiante> listar() throws SQLException {
        List<Estudiante> datos=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM estudiantes ORDER BY nombre"); ResultSet r=p.executeQuery()) {
            while(r.next()) datos.add(convertir(r));
        }
        return datos;
    }
    public Estudiante buscarPorId(int id) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM estudiantes WHERE id=?")) {
            p.setInt(1,id); try(ResultSet r=p.executeQuery()) {return r.next()?convertir(r):null;}
        }
    }
    public Estudiante buscarPorRut(String rut) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM estudiantes WHERE rut=?")) {
            p.setString(1,rut); try(ResultSet r=p.executeQuery()) {return r.next()?convertir(r):null;}
        }
    }
    public boolean insertar(Estudiante x) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("INSERT INTO estudiantes(nombre,rut,curso,correo) VALUES(?,?,?,?)")) {
            parametros(p,x); return p.executeUpdate()>0;
        }
    }
    public boolean actualizar(Estudiante x) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("UPDATE estudiantes SET nombre=?,rut=?,curso=?,correo=? WHERE id=?")) {
            parametros(p,x);p.setInt(5,x.getId());return p.executeUpdate()>0;
        }
    }
    private void parametros(PreparedStatement p,Estudiante x) throws SQLException {
        p.setString(1,x.getNombre());p.setString(2,x.getRut());p.setString(3,x.getCurso());p.setString(4,x.getCorreo());
    }
    public boolean eliminar(int id) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("DELETE FROM estudiantes WHERE id=?")) {
            p.setInt(1,id);return p.executeUpdate()>0;
        }
    }
}
