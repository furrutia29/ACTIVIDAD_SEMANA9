package dao;

import conexion.DatabaseConnection;
import modelo.Prestamo;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDAO {
    private Prestamo convertir(ResultSet r) throws SQLException {
        Date a=r.getDate("fecha_prestamo");
        Date b=r.getDate("fecha_devolucion");
        return new Prestamo(r.getInt("id"),r.getInt("id_estudiante"),r.getInt("id_libro"),
                a==null?null:a.toLocalDate(),b==null?null:b.toLocalDate(),r.getBoolean("devuelto"));
    }
    public List<Prestamo> listar() throws SQLException {
        List<Prestamo> datos=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM prestamos ORDER BY id DESC");ResultSet r=p.executeQuery()) {
            while(r.next()) datos.add(convertir(r));
        }
        return datos;
    }
    public List<Prestamo> listarPorEstudiante(int id) throws SQLException {
        List<Prestamo> datos=new ArrayList<>();
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM prestamos WHERE id_estudiante=? ORDER BY id DESC")) {
            p.setInt(1,id);
            try(ResultSet r=p.executeQuery()) {while(r.next()) datos.add(convertir(r));}
        }
        return datos;
    }
    public Prestamo buscarPorId(int id) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement p=c.prepareStatement("SELECT * FROM prestamos WHERE id=?")) {
            p.setInt(1,id);try(ResultSet r=p.executeQuery()) {return r.next()?convertir(r):null;}
        }
    }
    public synchronized boolean registrarPrestamo(int estudiante,int libro) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion()) {
            c.setAutoCommit(false);
            try {
                int stock;
                try(PreparedStatement p=c.prepareStatement("SELECT stock FROM libros WHERE id=? FOR UPDATE")) {
                    p.setInt(1,libro);
                    try(ResultSet r=p.executeQuery()) {
                        if(!r.next()) {c.rollback();return false;}
                        stock=r.getInt(1);
                    }
                }
                if(stock<=0) {c.rollback();return false;}
                try(PreparedStatement p=c.prepareStatement("SELECT id FROM prestamos WHERE id_estudiante=? AND id_libro=? AND devuelto=FALSE LIMIT 1")) {
                    p.setInt(1,estudiante);p.setInt(2,libro);
                    try(ResultSet r=p.executeQuery()) {if(r.next()) {c.rollback();return false;}}
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE libros SET stock=stock-1 WHERE id=? AND stock>0")) {
                    p.setInt(1,libro);
                    if(p.executeUpdate()!=1) throw new SQLException("No se pudo descontar el stock.");
                }
                try(PreparedStatement p=c.prepareStatement("INSERT INTO prestamos(id_estudiante,id_libro,fecha_prestamo,fecha_devolucion,devuelto) VALUES(?,?,?,?,FALSE)")) {
                    p.setInt(1,estudiante);p.setInt(2,libro);
                    LocalDate hoy=LocalDate.now();
                    p.setDate(3,Date.valueOf(hoy));p.setDate(4,Date.valueOf(hoy.plusDays(7)));
                    if(p.executeUpdate()!=1) throw new SQLException("No se pudo guardar el préstamo.");
                }
                c.commit();return true;
            } catch(SQLException | RuntimeException e) {revertir(c,e);throw e;}
        }
    }
    public synchronized boolean devolverLibro(int prestamo) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion()) {
            c.setAutoCommit(false);
            try {
                int libro;
                LocalDate vencimiento;
                try(PreparedStatement p=c.prepareStatement("SELECT id_libro,fecha_devolucion,devuelto FROM prestamos WHERE id=? FOR UPDATE")) {
                    p.setInt(1,prestamo);
                    try(ResultSet r=p.executeQuery()) {
                        if(!r.next()||r.getBoolean("devuelto")) {c.rollback();return false;}
                        libro=r.getInt("id_libro");
                        Date fecha=r.getDate("fecha_devolucion");
                        vencimiento=fecha==null?LocalDate.now():fecha.toLocalDate();
                    }
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE prestamos SET devuelto=TRUE WHERE id=?")) {
                    p.setInt(1,prestamo);
                    if(p.executeUpdate()!=1) throw new SQLException("No se pudo confirmar la devolución.");
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE libros SET stock=stock+1 WHERE id=?")) {
                    p.setInt(1,libro);
                    if(p.executeUpdate()!=1) throw new SQLException("No se pudo devolver el ejemplar al stock.");
                }
                long dias=Math.max(0,ChronoUnit.DAYS.between(vencimiento,LocalDate.now()));
                try(PreparedStatement p=c.prepareStatement("INSERT INTO registro_devoluciones(id_prestamo,fecha_real,dias_atraso) VALUES(?,?,?)")) {
                    p.setInt(1,prestamo);p.setDate(2,Date.valueOf(LocalDate.now()));p.setLong(3,dias);
                    if(p.executeUpdate()!=1) throw new SQLException("No se pudo guardar el registro de devolución.");
                }
                c.commit();return true;
            } catch(SQLException | RuntimeException e) {revertir(c,e);throw e;}
        }
    }
    private void revertir(Connection c,Exception e) {
        try { c.rollback(); } catch(SQLException ex) { e.addSuppressed(ex); }
    }
}
