package dao;

import conexion.DatabaseConnection;
import modelo.Libro;
import java.sql.*;
import java.util.*;

public class LibroDAO {
    private Libro convertir(ResultSet rs) throws SQLException {
        return new Libro(rs.getInt("id"),rs.getString("titulo"),rs.getString("autor"),
                rs.getString("isbn"),rs.getString("editorial"),rs.getInt("stock"),rs.getInt("id_categoria"));
    }
    public List<Libro> listar() throws SQLException {
        List<Libro> datos=new ArrayList<>();
        try (Connection c=DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps=c.prepareStatement("SELECT * FROM libros ORDER BY titulo");
             ResultSet rs=ps.executeQuery()) {
            while(rs.next()) datos.add(convertir(rs));
        }
        return datos;
    }
    public Libro buscarPorId(int id) throws SQLException {
        try (Connection c=DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps=c.prepareStatement("SELECT * FROM libros WHERE id=?")) {
            ps.setInt(1,id);
            try(ResultSet rs=ps.executeQuery()) { return rs.next()?convertir(rs):null; }
        }
    }
    public boolean insertar(Libro x) throws SQLException {
        if(x.getStock()<0) throw new IllegalArgumentException("El stock no puede ser negativo.");
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement ps=c.prepareStatement("INSERT INTO libros(titulo,autor,isbn,editorial,stock,id_categoria) VALUES(?,?,?,?,?,?)")) {
            parametros(ps,x); return ps.executeUpdate()>0;
        }
    }
    public boolean actualizar(Libro x) throws SQLException {
        if(x.getStock()<0) throw new IllegalArgumentException("El stock no puede ser negativo.");
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement ps=c.prepareStatement("UPDATE libros SET titulo=?,autor=?,isbn=?,editorial=?,stock=?,id_categoria=? WHERE id=?")) {
            parametros(ps,x); ps.setInt(7,x.getId()); return ps.executeUpdate()>0;
        }
    }
    private void parametros(PreparedStatement ps, Libro x) throws SQLException {
        ps.setString(1,x.getTitulo()); ps.setString(2,x.getAutor()); ps.setString(3,x.getIsbn());
        ps.setString(4,x.getEditorial()); ps.setInt(5,x.getStock()); ps.setInt(6,x.getIdCategoria());
    }
    public boolean eliminar(int id) throws SQLException {
        try(Connection c=DatabaseConnection.getInstance().nuevaConexion();
            PreparedStatement ps=c.prepareStatement("DELETE FROM libros WHERE id=?")) {
            ps.setInt(1,id); return ps.executeUpdate()>0;
        }
    }
}
