package dao;

import conexion.DatabaseConnection;
import modelo.Categoria;
import java.sql.*;
import java.util.*;

public class CategoriaDAO {
    public List<Categoria> listar() throws SQLException {
        List<Categoria> datos = new ArrayList<>();
        try (Connection c = DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps = c.prepareStatement("SELECT id,nombre FROM categorias ORDER BY nombre");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) datos.add(new Categoria(rs.getInt("id"), rs.getString("nombre")));
        }
        return datos;
    }
    public Categoria buscarPorId(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps = c.prepareStatement("SELECT id,nombre FROM categorias WHERE id=?")) {
            ps.setInt(1,id);
            try (ResultSet rs=ps.executeQuery()) {
                return rs.next()?new Categoria(rs.getInt("id"),rs.getString("nombre")):null;
            }
        }
    }
    public boolean insertar(Categoria x) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps=c.prepareStatement("INSERT INTO categorias(nombre) VALUES(?)")) {
            ps.setString(1,x.getNombre()); return ps.executeUpdate()>0;
        }
    }
    public boolean actualizar(Categoria x) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps=c.prepareStatement("UPDATE categorias SET nombre=? WHERE id=?")) {
            ps.setString(1,x.getNombre()); ps.setInt(2,x.getId()); return ps.executeUpdate()>0;
        }
    }
    public boolean eliminar(int id) throws SQLException {
        try (Connection c = DatabaseConnection.getInstance().nuevaConexion();
             PreparedStatement ps=c.prepareStatement("DELETE FROM categorias WHERE id=?")) {
            ps.setInt(1,id); return ps.executeUpdate()>0;
        }
    }
}
