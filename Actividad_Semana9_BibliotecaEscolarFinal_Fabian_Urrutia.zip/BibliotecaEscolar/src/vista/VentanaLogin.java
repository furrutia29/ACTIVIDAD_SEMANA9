package vista;

import controlador.AutenticacionControlador;
import modelo.Usuario;
import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;

public class VentanaLogin extends JFrame {
    private final JTextField correo = new JTextField(24);
    private final JPasswordField clave = new JPasswordField(24);
    private final JButton ingresar = new JButton("Ingresar");
    private final JLabel mensaje = new JLabel(" ");
    private final AutenticacionControlador controlador = new AutenticacionControlador();

    public VentanaLogin() {
        super("Biblioteca Escolar | Acceso");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 320);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        JPanel contenido = new JPanel(new GridBagLayout());
        contenido.setBorder(BorderFactory.createEmptyBorder(20,30,15,30));
        GridBagConstraints g=new GridBagConstraints();
        g.insets=new Insets(7,7,7,7);g.fill=GridBagConstraints.HORIZONTAL;
        JLabel titulo=new JLabel("Sistema de Biblioteca Escolar",SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD,19f));
        g.gridx=0;g.gridy=0;g.gridwidth=2;contenido.add(titulo,g);
        g.gridwidth=1;g.gridy=1;contenido.add(new JLabel("Correo:"),g);
        g.gridx=1;contenido.add(correo,g);
        g.gridx=0;g.gridy=2;contenido.add(new JLabel("Contraseña:"),g);
        g.gridx=1;contenido.add(clave,g);
        g.gridx=0;g.gridy=3;g.gridwidth=2;contenido.add(ingresar,g);
        g.gridy=4;mensaje.setForeground(new Color(160,35,35));contenido.add(mensaje,g);
        add(contenido,BorderLayout.CENTER);
        ingresar.addActionListener(e -> autenticar());
        getRootPane().setDefaultButton(ingresar);
    }

    private void autenticar() {
        String usuario=correo.getText().trim();
        char[] temporal=clave.getPassword();
        String contrasena=new String(temporal);
        Arrays.fill(temporal,'\0');
        ingresar.setEnabled(false);mensaje.setText("Comprobando acceso...");
        new SwingWorker<Usuario,Void>() {
            @Override protected Usuario doInBackground() throws Exception {
                return controlador.ingresar(usuario,contrasena);
            }
            @Override protected void done() {
                ingresar.setEnabled(true);
                try {
                    Usuario actual=get();
                    if(actual==null) {mensaje.setText("Correo o contraseña incorrectos.");return;}
                    VentanaPrincipal ventana=new VentanaPrincipal(actual);
                    ventana.setVisible(true);
                    dispose();
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();mensaje.setText("Operación interrumpida.");
                } catch(ExecutionException ex) {
                    String m=ex.getCause()==null?ex.getMessage():ex.getCause().getMessage();
                    mensaje.setText("No fue posible ingresar.");
                    JOptionPane.showMessageDialog(VentanaLogin.this,m,"Error de conexión",JOptionPane.ERROR_MESSAGE);
                } catch(Exception ex) {
                    mensaje.setText("No se pudo abrir la aplicación.");
                    JOptionPane.showMessageDialog(VentanaLogin.this,ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }
}
