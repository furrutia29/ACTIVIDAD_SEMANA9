package vista;

import controlador.BibliotecaControlador;
import modelo.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

public class VentanaPrincipal extends JFrame {
    private final BibliotecaControlador controlador;
    private final JLabel estado = new JLabel("Listo");
    private final JTabbedPane pestanas = new JTabbedPane();
    private final boolean admin;

    public VentanaPrincipal(Usuario usuario) throws Exception {
        super("Biblioteca Escolar | Gestión");
        controlador = new BibliotecaControlador(usuario);
        admin = controlador.esBibliotecario();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1120, 720);
        setMinimumSize(new Dimension(900,580));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(0,8));

        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBorder(BorderFactory.createEmptyBorder(12,16,8,16));
        JLabel usuarioActual = new JLabel("Biblioteca Escolar     |     " + usuario.getNombre()
                + "     |     " + usuario.getRol().toUpperCase());
        usuarioActual.setFont(usuarioActual.getFont().deriveFont(Font.BOLD,16f));
        encabezado.add(usuarioActual,BorderLayout.WEST);
        JButton salir=new JButton("Cerrar sesión");
        salir.addActionListener(e->{new VentanaLogin().setVisible(true);dispose();});
        encabezado.add(salir,BorderLayout.EAST);
        add(encabezado,BorderLayout.NORTH);

        pestanas.addTab(admin?"Libros":"Catálogo", panelLibros());
        if(admin) {
            pestanas.addTab("Categorías", panelCategorias());
            pestanas.addTab("Estudiantes", panelEstudiantes());
            pestanas.addTab("Usuarios", panelUsuarios());
        }
        pestanas.addTab(admin?"Préstamos":"Mis préstamos", panelPrestamos());
        if(admin) pestanas.addTab("Reportes", panelReportes());
        add(pestanas,BorderLayout.CENTER);
        JPanel pie=new JPanel(new BorderLayout());
        pie.setBorder(BorderFactory.createEmptyBorder(5,14,8,14));
        pie.add(estado,BorderLayout.WEST);
        add(pie,BorderLayout.SOUTH);
    }

    private JTable tabla(String... columnas) {
        DefaultTableModel modelo=new DefaultTableModel(columnas,0) {
            @Override public boolean isCellEditable(int fila,int columna) {return false;}
        };
        JTable t=new JTable(modelo);
        t.setRowHeight(27);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setAutoCreateRowSorter(true);
        t.getTableHeader().setReorderingAllowed(false);
        return t;
    }
    private void datos(JTable t,List<Object[]> filas) {
        DefaultTableModel m=(DefaultTableModel)t.getModel();
        m.setRowCount(0);
        for(Object[] f:filas) m.addRow(f);
    }
    private int idSeleccionado(JTable t) {
        int indice=t.getSelectedRow();
        if(indice<0) throw new IllegalArgumentException("Selecciona primero una fila de la tabla.");
        int modelo=t.convertRowIndexToModel(indice);
        return Integer.parseInt(t.getModel().getValueAt(modelo,0).toString());
    }
    private JPanel base(String texto,JTable tabla,JPanel botones) {
        JPanel panel=new JPanel(new BorderLayout(0,9));
        panel.setBorder(BorderFactory.createEmptyBorder(10,12,10,12));
        JLabel titulo=new JLabel(texto);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD,15f));
        panel.add(titulo,BorderLayout.NORTH);
        panel.add(new JScrollPane(tabla),BorderLayout.CENTER);
        panel.add(botones,BorderLayout.SOUTH);
        return panel;
    }
    private JPanel botones() { return new JPanel(new FlowLayout(FlowLayout.LEFT,9,3)); }
    private JButton boton(JPanel p,String texto,Runnable accion) {
        JButton b=new JButton(texto);
        b.addActionListener(e->{try {accion.run();}catch(Exception ex){error(ex);}});
        p.add(b);return b;
    }
    private <T> void ejecutar(String tarea,Callable<T> operacion,Consumer<T> alTerminar) {
        estado.setText(tarea+"...");
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        new SwingWorker<T,Void>() {
            @Override protected T doInBackground() throws Exception {return operacion.call();}
            @Override protected void done() {
                setCursor(Cursor.getDefaultCursor());
                try {T resultado=get();estado.setText("Listo: "+tarea);alTerminar.accept(resultado);}
                catch(InterruptedException ex){Thread.currentThread().interrupt();estado.setText("Interrumpido");}
                catch(ExecutionException ex){estado.setText("Error en "+tarea);error(ex.getCause());}
                catch(Exception ex){estado.setText("Error");error(ex);}
            }
        }.execute();
    }
    private void cambio(String titulo,Callable<Void> accion,Runnable actualizar) {
        ejecutar(titulo,accion,x->{
            JOptionPane.showMessageDialog(this,"Operación realizada correctamente.","Biblioteca",JOptionPane.INFORMATION_MESSAGE);
            actualizar.run();
        });
    }
    private void error(Throwable ex) {
        Throwable causa=ex;
        while(causa.getCause()!=null) causa=causa.getCause();
        JOptionPane.showMessageDialog(this,causa.getMessage()==null?causa.toString():causa.getMessage(),
                "No se pudo completar",JOptionPane.ERROR_MESSAGE);
    }
    private boolean confirmar(String msg) {
        return JOptionPane.showConfirmDialog(this,msg,"Confirmar operación",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION;
    }
    private String[] formulario(String titulo,String[] etiquetas,String[] valores) {
        JPanel panel=new JPanel(new GridLayout(0,2,8,9));
        JTextField[] campos=new JTextField[etiquetas.length];
        for(int i=0;i<etiquetas.length;i++) {
            panel.add(new JLabel(etiquetas[i]));
            campos[i]=etiquetas[i].startsWith("Contraseña")
                    ? new JPasswordField(valores==null?"":valores[i],24)
                    : new JTextField(valores==null?"":valores[i],24);
            panel.add(campos[i]);
        }
        int opcion=JOptionPane.showConfirmDialog(this,panel,titulo,JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
        if(opcion!=JOptionPane.OK_OPTION) return null;
        String[] resultado=new String[campos.length];
        for(int i=0;i<campos.length;i++) {
            if(campos[i] instanceof JPasswordField secreto) {
                char[] caracteres=secreto.getPassword();
                resultado[i]=new String(caracteres);
                Arrays.fill(caracteres,'\0');
            } else resultado[i]=campos[i].getText().trim();
        }
        return resultado;
    }
    private int numero(String s,String campo) {
        try {return Integer.parseInt(s.trim());}
        catch(NumberFormatException ex){throw new IllegalArgumentException("Introduce un número válido en: "+campo);}
    }
    private String texto(String s,String nombre) {
        if(s==null||s.isBlank()) throw new IllegalArgumentException(nombre+" no puede quedar vacío.");
        return s;
    }

    private JPanel panelLibros() {
        JTable t=tabla("ID","Título","Autor","ISBN","Editorial","Stock","Categoría ID");
        JPanel acciones=botones();
        List<Libro> libros=new ArrayList<>();
        Runnable refrescar=()->ejecutar("Cargando libros",controlador::listarLibros,lista->{
            libros.clear();libros.addAll(lista);
            List<Object[]> f=new ArrayList<>();
            for(Libro x:lista) f.add(new Object[]{x.getId(),x.getTitulo(),x.getAutor(),x.getIsbn(),x.getEditorial(),x.getStock(),x.getIdCategoria()});
            datos(t,f);
        });
        boton(acciones,"Actualizar",refrescar);
        if(admin) {
            boton(acciones,"Nuevo libro",()->editarLibro(null,refrescar));
            boton(acciones,"Modificar",()->{
                int id=idSeleccionado(t);
                Libro elegido=libros.stream().filter(x->x.getId()==id).findFirst().orElseThrow();
                editarLibro(elegido,refrescar);
            });
            boton(acciones,"Eliminar",()->{
                int id=idSeleccionado(t);
                if(confirmar("¿Eliminar el libro seleccionado?")) cambio("Eliminando libro",()->{controlador.eliminarLibro(id);return null;},refrescar);
            });
        } else {
            boton(acciones,"Solicitar libro",()->{
                int id=idSeleccionado(t);
                Integer estudiante=controlador.getIdEstudiante();
                if(estudiante==null) throw new IllegalStateException("No existe una ficha de estudiante asociada a tu RUT.");
                if(!confirmar("¿Solicitar préstamo de este libro por 7 días?")) return;
                ejecutar("Registrando préstamo",()->{controlador.prestar(estudiante,id);return null;},x->{
                    JOptionPane.showMessageDialog(this,"Préstamo registrado. Revisa Mis préstamos.");
                    refrescar.run();
                });
            });
        }
        JPanel p=base(admin?"Inventario y mantenimiento de libros":"Consulta del catálogo y préstamos",t,acciones);
        SwingUtilities.invokeLater(refrescar);return p;
    }
    private void editarLibro(Libro original,Runnable refrescar) {
        String[] e={"Título","Autor","ISBN","Editorial","Stock disponible","ID de categoría (ver pestaña Categorías)"};
        String[] v=original==null?null:new String[]{original.getTitulo(),original.getAutor(),original.getIsbn(),
                original.getEditorial(),""+original.getStock(),""+original.getIdCategoria()};
        String[] d=formulario(original==null?"Registrar libro":"Modificar libro",e,v);
        if(d==null)return;
        Libro x=new Libro(original==null?0:original.getId(),texto(d[0],"Título"),d[1],texto(d[2],"ISBN"),d[3],
                numero(d[4],"Stock"),numero(d[5],"Categoría"));
        cambio("Guardando libro",()->{controlador.guardarLibro(x);return null;},refrescar);
    }

    private JPanel panelCategorias() {
        JTable t=tabla("ID","Nombre");JPanel acciones=botones();
        List<Categoria> categorias=new ArrayList<>();
        Runnable refrescar=()->ejecutar("Cargando categorías",controlador::listarCategorias,lista->{
            categorias.clear();categorias.addAll(lista);
            List<Object[]> f=new ArrayList<>();for(Categoria x:lista) f.add(new Object[]{x.getId(),x.getNombre()});datos(t,f);
        });
        boton(acciones,"Actualizar",refrescar);
        boton(acciones,"Nueva",()->editarCategoria(null,refrescar));
        boton(acciones,"Modificar",()->{
            int id=idSeleccionado(t);
            editarCategoria(categorias.stream().filter(x->x.getId()==id).findFirst().orElseThrow(),refrescar);
        });
        boton(acciones,"Eliminar",()->{
            int id=idSeleccionado(t);
            if(confirmar("¿Eliminar esta categoría? No se puede si tiene libros asociados."))
                cambio("Eliminando categoría",()->{controlador.eliminarCategoria(id);return null;},refrescar);
        });
        JPanel p=base("Categorías de libros",t,acciones);SwingUtilities.invokeLater(refrescar);return p;
    }
    private void editarCategoria(Categoria original,Runnable refrescar) {
        String[] datos=formulario("Categoría",new String[]{"Nombre"},original==null?null:new String[]{original.getNombre()});
        if(datos==null)return;
        Categoria x=new Categoria(original==null?0:original.getId(),texto(datos[0],"Nombre"));
        cambio("Guardando categoría",()->{controlador.guardarCategoria(x);return null;},refrescar);
    }

    private JPanel panelEstudiantes() {
        JTable t=tabla("ID","Nombre","RUT","Curso","Correo");JPanel acciones=botones();
        List<Estudiante> estudiantes=new ArrayList<>();
        Runnable refrescar=()->ejecutar("Cargando estudiantes",controlador::listarEstudiantes,lista->{
            estudiantes.clear();estudiantes.addAll(lista);
            List<Object[]> f=new ArrayList<>();for(Estudiante x:lista)
                f.add(new Object[]{x.getId(),x.getNombre(),x.getRut(),x.getCurso(),x.getCorreo()});
            datos(t,f);
        });
        boton(acciones,"Actualizar",refrescar);
        boton(acciones,"Nuevo",()->editarEstudiante(null,refrescar));
        boton(acciones,"Modificar",()->{
            int id=idSeleccionado(t);
            editarEstudiante(estudiantes.stream().filter(x->x.getId()==id).findFirst().orElseThrow(),refrescar);
        });
        boton(acciones,"Eliminar",()->{
            int id=idSeleccionado(t);
            if(confirmar("¿Eliminar al estudiante seleccionado? Los préstamos asociados pueden impedirlo."))
                cambio("Eliminando estudiante",()->{controlador.eliminarEstudiante(id);return null;},refrescar);
        });
        JPanel p=base("Mantenimiento de estudiantes",t,acciones);SwingUtilities.invokeLater(refrescar);return p;
    }
    private void editarEstudiante(Estudiante original,Runnable refrescar) {
        String[] e={"Nombre","RUT","Correo","Curso"};
        String[] v=original==null?null:new String[]{original.getNombre(),original.getRut(),original.getCorreo(),original.getCurso()};
        String[] d=formulario("Datos del estudiante",e,v);
        if(d==null)return;
        Estudiante x=new Estudiante(original==null?0:original.getId(),texto(d[0],"Nombre"),texto(d[1],"RUT"),d[2],d[3]);
        cambio("Guardando estudiante",()->{controlador.guardarEstudiante(x);return null;},refrescar);
    }

    private JPanel panelUsuarios() {
        JTable t=tabla("ID","Nombre","RUT","Correo","Rol");JPanel acciones=botones();
        List<Usuario> usuarios=new ArrayList<>();
        Runnable refrescar=()->ejecutar("Cargando usuarios",controlador::listarUsuarios,lista->{
            usuarios.clear();usuarios.addAll(lista);
            List<Object[]> f=new ArrayList<>();for(Usuario x:lista)
                f.add(new Object[]{x.getId(),x.getNombre(),x.getRut(),x.getCorreo(),x.getRol()});
            datos(t,f);
        });
        boton(acciones,"Actualizar",refrescar);
        boton(acciones,"Nuevo",()->editarUsuario(null,refrescar));
        boton(acciones,"Modificar",()->{
            int id=idSeleccionado(t);editarUsuario(usuarios.stream().filter(x->x.getId()==id).findFirst().orElseThrow(),refrescar);
        });
        boton(acciones,"Eliminar",()->{
            int id=idSeleccionado(t);
            if(confirmar("¿Eliminar al usuario seleccionado?")) cambio("Eliminando usuario",()->{controlador.eliminarUsuario(id);return null;},refrescar);
        });
        JPanel p=base("Cuentas y roles (las contraseñas no se muestran)",t,acciones);SwingUtilities.invokeLater(refrescar);return p;
    }
    private void editarUsuario(Usuario original,Runnable refrescar) {
        String[] e={"Nombre","RUT","Correo","Contraseña (en edición, vacío = conservar)","Rol: bibliotecario o estudiante"};
        String[] v=original==null?null:new String[]{original.getNombre(),original.getRut(),original.getCorreo(),"",original.getRol()};
        String[] d=formulario("Cuenta de usuario",e,v);
        if(d==null)return;
        String clave=d[3].isBlank()&&original!=null?original.getContrasena():d[3];
        Usuario x=new Usuario(original==null?0:original.getId(),texto(d[0],"Nombre"),texto(d[1],"RUT"),
                texto(d[2],"Correo"),clave,texto(d[4],"Rol").toLowerCase());
        cambio("Guardando usuario",()->{controlador.guardarUsuario(x);return null;},refrescar);
    }

    private JPanel panelPrestamos() {
        JTable t=tabla("ID","Estudiante","Libro","Fecha","Vencimiento","Estado");
        JPanel acciones=botones();
        Runnable refrescar=()->ejecutar("Cargando préstamos",()->{
            List<Prestamo> prestamos=controlador.listarPrestamos();
            List<Libro> libros=controlador.listarLibros();
            List<Estudiante> estudiantes=admin?controlador.listarEstudiantes():List.of();
            Map<Integer,String> nombresLibros=new HashMap<>();for(Libro l:libros)nombresLibros.put(l.getId(),l.getTitulo());
            Map<Integer,String> nombresEstudiantes=new HashMap<>();for(Estudiante e:estudiantes)nombresEstudiantes.put(e.getId(),e.getNombre());
            List<Object[]> filas=new ArrayList<>();
            for(Prestamo p:prestamos) {
                String situacion=p.isDevuelto()?"DEVUELTO":
                        p.getFechaDevolucion()!=null&&p.getFechaDevolucion().isBefore(java.time.LocalDate.now())?"ATRASADO":"PENDIENTE";
                filas.add(new Object[]{p.getId(),nombresEstudiantes.getOrDefault(p.getIdEstudiante(),"ID "+p.getIdEstudiante()),
                        nombresLibros.getOrDefault(p.getIdLibro(),"ID "+p.getIdLibro()),p.getFechaPrestamo(),p.getFechaDevolucion(),situacion});
            }
            return filas;
        },filas->datos(t,filas));
        boton(acciones,"Actualizar",refrescar);
        if(admin) {
            boton(acciones,"Registrar préstamo",()->{
                String[] d=formulario("Nuevo préstamo",new String[]{"ID estudiante","ID libro"},null);
                if(d==null)return;
                int idEstudiante=numero(d[0],"ID estudiante");int idLibro=numero(d[1],"ID libro");
                if(confirmar("¿Prestar libro "+idLibro+" al estudiante "+idEstudiante+" por 7 días?"))
                    cambio("Registrando préstamo",()->{controlador.prestar(idEstudiante,idLibro);return null;},refrescar);
            });
        }
        boton(acciones,"Registrar devolución",()->{
            int id=idSeleccionado(t);
            if(confirmar("¿Registrar la devolución del préstamo "+id+"?"))
                cambio("Registrando devolución",()->{controlador.devolver(id);return null;},refrescar);
        });
        JPanel p=base(admin?"Administración de préstamos y devoluciones":"Mis préstamos y devoluciones",t,acciones);
        SwingUtilities.invokeLater(refrescar);return p;
    }

    private JPanel panelReportes() {
        String[][] cabeceras={
            {"Libro","Autor","Veces prestado"},
            {"ID préstamo","Estudiante","Libro","Fecha","Vencimiento","Estado"},
            {"ID préstamo","Libro","Fecha","Vencimiento","Estado"},
            {"ID préstamo","Estudiante","Libro","Fecha real","Días de atraso"}
        };
        String[] opciones={"Libros más prestados","Préstamos activos","Historial de estudiante","Registro de devoluciones"};
        JPanel p=new JPanel(new BorderLayout(0,10));
        p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        JPanel arriba=new JPanel(new FlowLayout(FlowLayout.LEFT,12,6));
        JComboBox<String> tipo=new JComboBox<>(opciones);
        JTextField idEstudiante=new JTextField("1",5);
        JButton mostrar=new JButton("Consultar");
        arriba.add(new JLabel("Reporte:"));arriba.add(tipo);
        arriba.add(new JLabel("ID estudiante (historial):"));arriba.add(idEstudiante);arriba.add(mostrar);
        p.add(arriba,BorderLayout.NORTH);
        JTable t=tabla(cabeceras[0]);
        p.add(new JScrollPane(t),BorderLayout.CENTER);
        mostrar.addActionListener(e->{
            try {
                int seleccionado=tipo.getSelectedIndex();
                int estudiante=seleccionado==2?numero(idEstudiante.getText(),"ID estudiante"):0;
                ejecutar("Consultando reporte",()->switch(seleccionado) {
                    case 0 -> controlador.reporteMasPrestados();
                    case 1 -> controlador.reporteActivos();
                    case 2 -> controlador.reporteHistorial(estudiante);
                    default -> controlador.reporteDevoluciones();
                },filas->{
                    t.setModel(new DefaultTableModel(cabeceras[seleccionado],0){
                        @Override public boolean isCellEditable(int f,int c){return false;}
                    });
                    datos(t,filas);
                });
            }catch(Exception ex){error(ex);}
        });
        SwingUtilities.invokeLater(mostrar::doClick);
        return p;
    }
}
