package controlador;

import dao.*;
import modelo.*;
import java.sql.SQLException;
import java.util.List;

public class BibliotecaControlador {
    private final Usuario sesion;
    private final Integer idEstudiante;
    private final CategoriaDAO categorias = new CategoriaDAO();
    private final LibroDAO libros = new LibroDAO();
    private final EstudianteDAO estudiantes = new EstudianteDAO();
    private final UsuarioDAO usuarios = new UsuarioDAO();
    private final PrestamoDAO prestamos = new PrestamoDAO();
    private final ReporteDAO reportes = new ReporteDAO();

    public BibliotecaControlador(Usuario sesion) throws SQLException {
        this.sesion = sesion;
        if (esBibliotecario()) {
            idEstudiante = null;
        } else {
            Estudiante encontrado = estudiantes.buscarPorRut(sesion.getRut());
            idEstudiante = encontrado == null ? null : encontrado.getId();
        }
    }
    public Usuario getSesion() { return sesion; }
    public boolean esBibliotecario() { return "bibliotecario".equalsIgnoreCase(sesion.getRol()); }
    public Integer getIdEstudiante() { return idEstudiante; }

    private void soloBibliotecario() {
        if (!esBibliotecario()) throw new SecurityException("Esta función es exclusiva de bibliotecarios.");
    }
    public List<Libro> listarLibros() throws SQLException { return libros.listar(); }
    public List<Categoria> listarCategorias() throws SQLException { return categorias.listar(); }
    public List<Estudiante> listarEstudiantes() throws SQLException { soloBibliotecario(); return estudiantes.listar(); }
    public List<Usuario> listarUsuarios() throws SQLException { soloBibliotecario(); return usuarios.listar(); }
    public List<Prestamo> listarPrestamos() throws SQLException {
        if (esBibliotecario()) return prestamos.listar();
        if (idEstudiante == null) throw new IllegalStateException("Tu usuario no tiene una ficha de estudiante asociada al RUT.");
        return prestamos.listarPorEstudiante(idEstudiante);
    }
    public List<Object[]> reporteMasPrestados() throws SQLException { soloBibliotecario(); return reportes.masPrestados(); }
    public List<Object[]> reporteActivos() throws SQLException { soloBibliotecario(); return reportes.activos(); }
    public List<Object[]> reporteHistorial(int estudiante) throws SQLException { soloBibliotecario(); return reportes.historial(estudiante); }
    public List<Object[]> reporteDevoluciones() throws SQLException { soloBibliotecario(); return reportes.devoluciones(); }

    public void guardarLibro(Libro x) throws SQLException {
        soloBibliotecario();
        if(x.getTitulo().isBlank() || x.getIsbn().isBlank()) throw new IllegalArgumentException("El título y el ISBN son obligatorios.");
        if(x.getStock()<0) throw new IllegalArgumentException("El stock debe ser 0 o más.");
        if(x.getId()==0) libros.insertar(x); else libros.actualizar(x);
    }
    public void eliminarLibro(int id) throws SQLException { soloBibliotecario(); libros.eliminar(id); }
    public void guardarCategoria(Categoria x) throws SQLException {
        soloBibliotecario();if(x.getNombre().isBlank()) throw new IllegalArgumentException("El nombre es obligatorio.");
        if(x.getId()==0) categorias.insertar(x); else categorias.actualizar(x);
    }
    public void eliminarCategoria(int id) throws SQLException { soloBibliotecario();categorias.eliminar(id); }
    public void guardarEstudiante(Estudiante x) throws SQLException {
        soloBibliotecario();
        if(x.getNombre().isBlank() || x.getRut().isBlank()) throw new IllegalArgumentException("Nombre y RUT obligatorios.");
        if(x.getId()==0) estudiantes.insertar(x); else estudiantes.actualizar(x);
    }
    public void eliminarEstudiante(int id) throws SQLException { soloBibliotecario();estudiantes.eliminar(id); }
    public void guardarUsuario(Usuario x) throws SQLException {
        soloBibliotecario();
        if(x.getNombre().isBlank() || x.getRut().isBlank() || x.getCorreo().isBlank())
            throw new IllegalArgumentException("Nombre, RUT y correo son obligatorios.");
        if(x.getContrasena().isBlank()) throw new IllegalArgumentException("La contraseña no puede estar vacía.");
        if(!x.getRol().equals("bibliotecario") && !x.getRol().equals("estudiante"))
            throw new IllegalArgumentException("Rol no reconocido.");
        if(x.getId()==0) usuarios.insertar(x); else usuarios.actualizar(x);
    }
    public void eliminarUsuario(int id) throws SQLException {
        soloBibliotecario();
        if(id==sesion.getId()) throw new IllegalArgumentException("No puedes eliminar tu propia cuenta durante la sesión.");
        usuarios.eliminar(id);
    }
    public void prestar(int estudiante,int libro) throws SQLException {
        if(!esBibliotecario() && (idEstudiante==null || estudiante!=idEstudiante))
            throw new SecurityException("Solo puedes solicitar libros para tu propia ficha.");
        if(!prestamos.registrarPrestamo(estudiante,libro))
            throw new IllegalArgumentException("No fue posible el préstamo: revisa stock y préstamos pendientes.");
    }
    public void devolver(int idPrestamo) throws SQLException {
        if (!esBibliotecario()) {
            Prestamo prestamo = prestamos.buscarPorId(idPrestamo);
            if(prestamo==null || idEstudiante==null || prestamo.getIdEstudiante()!=idEstudiante)
                throw new SecurityException("No puedes devolver préstamos de otras personas.");
        }
        if(!prestamos.devolverLibro(idPrestamo)) throw new IllegalArgumentException("El préstamo no existe o ya fue devuelto.");
    }
}
