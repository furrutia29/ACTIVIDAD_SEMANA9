package controlador;

import dao.UsuarioDAO;
import modelo.Usuario;
import java.sql.SQLException;

public class AutenticacionControlador {
    private final UsuarioDAO usuarios = new UsuarioDAO();

    public Usuario ingresar(String correo, String clave) throws SQLException {
        if (correo == null || correo.isBlank() || clave == null || clave.isBlank()) {
            throw new IllegalArgumentException("Ingresa correo y contraseña.");
        }
        return usuarios.autenticar(correo, clave);
    }
}
