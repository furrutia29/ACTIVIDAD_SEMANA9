package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DatabaseConnection {
    private static final DatabaseConnection INSTANCIA = new DatabaseConnection();
    private static final String URL = "jdbc:mysql://localhost:3306/biblioteca";
    private static final String USUARIO = "root";

    private DatabaseConnection() { }

    public static DatabaseConnection getInstance() {
        return INSTANCIA;
    }

    public Connection getConnection() throws SQLException {
        return nuevaConexion();
    }

    public Connection nuevaConexion() throws SQLException {
        String clave = System.getenv("BIBLIOTECA_DB_PASSWORD");
        if (clave == null) {
            throw new SQLException("Configura BIBLIOTECA_DB_PASSWORD en las variables de entorno de ejecución.");
        }
        return DriverManager.getConnection(URL, USUARIO, clave);
    }
}
